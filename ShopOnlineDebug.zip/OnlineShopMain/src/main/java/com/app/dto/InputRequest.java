package com.app.dto;

import java.util.Scanner;

import com.app.model.Electronics;
import com.app.model.Fashion;
import com.app.model.Healthcare;
import com.app.model.User;

public class InputRequest {
	static  Scanner sn=new Scanner(System.in);
 public static User register() {
	
	 System.out.println("Enter User Details:");
	 System.out.println("Enter user First name:");
	 String fname=sn.next();
	 System.out.println("Enter user Last name:");
	 String lname=sn.next();
	 System.out.println("Enter user address:");
	 String address=sn.next();
	 System.out.println("Enter user mobile:");
	 long mob=sn.nextLong();
	 System.out.println("Enter username:");
	 String uname=sn.next();
	 System.out.println("Enter user password:");
	 String pass=sn.next();
	 System.out.println("Enter user role:");
	 String role=sn.next();
	return addUser(fname, lname, address, mob, uname, pass, role);
	 
 }
public static UserRequest login() {
	System.out.println("Enter user  name:");
	 String uname=sn.next();
	 System.out.println("Enter user password:");
	 String pass=sn.next();
	 System.out.println("Enter user role:");
	 String role=sn.next();
	 return new UserRequest(uname,pass,role);
 }

public static Healthcare productList() {
	System.out.println("enter the id");
	int pid=sn.nextInt();
	System.out.println("enter the productName");
	String proName=sn.next();
	System.out.println("enter the manufacturing date- mm/yy");
	String mfg=sn.next();
	System.out.println("enter the expiry date - mm/yy");
	String exp=sn.next();
	System.out.println("enter the Rate ");
	int rate=sn.nextInt();
	return addProduct(pid,proName,mfg,exp,rate);
}

private static Healthcare addProduct(int pid, String proName, String mfg, String exp,int rate) {
	Healthcare health=new Healthcare();
	health.setProid(pid);
	health.setProName(proName);
	health.setMfg(mfg);
	health.setExp(exp);
	health.setRate(rate);
	return health;
}

public static Fashion productList1() {
	System.out.println("enter the id");
	int pid=sn.nextInt();
	System.out.println("enter the productName");
	String proname=sn.next();
	System.out.println("enter the product type");
	String proType=sn.next();
	System.out.println("enter the Rate ");
	int rate=sn.nextInt();
	return addProduct1(pid,proname,proType,rate);
}
	
private static Fashion addProduct1(int pid, String proname, String proType,int rate) {
		Fashion fashion=new Fashion();
		fashion.setProid(pid);
		fashion.setProname(proname);
		fashion.setProType(proType);
		fashion.setRate(rate);
		return fashion;
	}

public static Electronics productList2() {
	System.out.println("enter the id");
	int pid=sn.nextInt();
	System.out.println("enter the productName");
	String proname=sn.next();
	System.out.println("enter the Manufacturing date");
	String mfg=sn.next();
	System.out.println("enter the model number");
	String modelNo=sn.next();
	System.out.println("enter the Rate ");
	int rate=sn.nextInt();
	return addProduct2(pid,proname,mfg,modelNo,rate);
}

private static Electronics addProduct2(int pid, String proname, String mfg,String modelNo,int rate) {
	Electronics electronics=new Electronics();
	electronics.setProid(pid);
	electronics.setProname(proname);
	electronics.setModelNo(modelNo);
	electronics.setRate(rate);
	electronics.setMfg(mfg);
	return electronics;
}

private static User addUser(String fname, String lname, String address, long mob, String uname, String pass,
		String role) {
	User user=new User();
	 user.setAddress(address);
	 user.setFisrtName(fname);
	 user.setLastName(lname);
	 user.setMobile(mob);
	 user.setPassword(pass);
	 user.setRole(role);
	 user.setUname(uname);
	 return user;
}
}