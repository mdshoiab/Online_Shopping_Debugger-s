package com.app.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Electronics {
@GeneratedValue(strategy = GenerationType.AUTO)

@Id
private int proid;
private String proname;
private int rate;
private String mfg;
private String modelNo;
public int getProid() {
	return proid;
}
public void setProid(int proid) {
	this.proid = proid;
}
public String getProname() {
	return proname;
}
public void setProname(String proname) {
	this.proname = proname;
}
public int getRate() {
	return rate;
}
public void setRate(int rate) {
	this.rate = rate;
}
public String getMfg() {
	return mfg;
}
public void setMfg(String mfg) {
	this.mfg = mfg;
}
public String getModelNo() {
	return modelNo;
}
public void setModelNo(String modelNo) {
	this.modelNo = modelNo;
}
public Electronics(int proid, String proname, int rate, String mfg, String modelNo) {
	super();
	this.proid = proid;
	this.proname = proname;
	this.rate = rate;
	this.mfg = mfg;
	this.modelNo = modelNo;
}
public Electronics() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Electronics [proid=" + proid + ", proname=" + proname + ", rate=" + rate + ", mfg=" + mfg + ", modelNo="
			+ modelNo + "]";
}


}
