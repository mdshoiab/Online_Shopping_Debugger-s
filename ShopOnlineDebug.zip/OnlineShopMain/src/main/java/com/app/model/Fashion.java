package com.app.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Fashion {
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	@Id
	private int proid;
	private String proname;
	private int rate;
	private String proType;
	public int getProid() {
		return proid;
	}
	public void setProid(int proid) {
		this.proid = proid;
	}
	public String getProname() {
		return proname;
	}
	public void setProname(String proname) {
		this.proname = proname;
	}
	public int getRate() {
		return rate;
	}
	public void setRate(int rate) {
		this.rate = rate;
	}
	public String getProType() {
		return proType;
	}
	public void setProType(String proType) {
		this.proType = proType;
	}
	public Fashion(int proid, String proname, int rate, String proType) {
		super();
		this.proid = proid;
		this.proname = proname;
		this.rate = rate;
		this.proType = proType;
	}
	public Fashion() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Fashion [proid=" + proid + ", proname=" + proname + ", rate=" + rate + ", proType=" + proType + "]";
	}
	
	
	
	

}
