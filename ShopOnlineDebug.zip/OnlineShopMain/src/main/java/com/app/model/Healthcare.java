package com.app.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;

@Entity
public class Healthcare {
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	@Id
	private int proid;
	private String proName;
	private String mfg;
	private String exp;
	private int rate;
	public int id1=proid;
	public int getProid() {
		return proid;
	}
	public void setProid(int proid) {
		this.proid = proid;
	}
	public String getProName() {
		return proName;
	}
	public void setProName(String proName) {
		this.proName = proName;
	}
	public String getMfg() {
		return mfg;
	}
	public void setMfg(String mfg) {
		this.mfg = mfg;
	}
	public String getExp() {
		return exp;
	}
	public void setExp(String exp) {
		this.exp = exp;
	}
	public int getRate() {
		return rate;
	}
	public void setRate(int rate) {
		this.rate = rate;
	}
	public Healthcare(int proid, String proName, String mfg, String exp, int rate) {
		super();
		this.proid = proid;
		this.proName = proName;
		this.mfg = mfg;
		this.exp = exp;
		this.rate = rate;
	}
	public Healthcare() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Healthcare [proid=" + proid + ", proName=" + proName + ", mfg=" + mfg + ", exp=" + exp + ", rate="
				+ rate + "]";
	}
	
	

}
