package com.app.service;

import com.app.dto.InputRequest;
import com.app.model.Fashion;


public class FashionCareSer {
	public Fashion productList1() {
		return InputRequest.productList1();

}
}
