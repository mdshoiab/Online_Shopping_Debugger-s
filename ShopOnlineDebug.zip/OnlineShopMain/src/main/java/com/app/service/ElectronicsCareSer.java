package com.app.service;

import com.app.dto.InputRequest;
import com.app.model.Electronics;


public class ElectronicsCareSer {
	public Electronics productList2() {
		return InputRequest.productList2();

}
}
