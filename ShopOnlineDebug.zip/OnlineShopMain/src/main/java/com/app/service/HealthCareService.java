package com.app.service;

import com.app.dto.InputRequest;
import com.app.model.Healthcare;

public class HealthCareService {
	public Healthcare productList() {
		return InputRequest.productList();
	}
}
