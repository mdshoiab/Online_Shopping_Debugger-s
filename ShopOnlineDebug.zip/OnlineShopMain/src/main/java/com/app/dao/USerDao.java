package com.app.dao;

import java.util.List;

import com.app.dto.UserRequest;
import com.app.model.Electronics;
import com.app.model.Fashion;
import com.app.model.Healthcare;
import com.app.model.User;

public interface USerDao {
int register();
User login();
List<User> listOfUsers();
List<Healthcare> listOfHealthcare();
List<Fashion> listOfFashion();
List<Electronics> listOfElectronics();
User findById(int id);
Healthcare productList();
Fashion productList1();
Electronics productList2();


}
