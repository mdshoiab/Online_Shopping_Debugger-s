package com.app.dao.impl;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import com.app.dao.USerDao;

import com.app.dto.UserRequest;
import com.app.model.Electronics;
import com.app.model.Fashion;
import com.app.model.Healthcare;
import com.app.model.User;
import com.app.service.ElectronicsCareSer;
import com.app.service.FashionCareSer;
import com.app.service.HealthCareService;
import com.app.service.UserService;


public class UserDaoImpl implements USerDao {
	

	public int register() {
		// TODO Auto-generated method stub
		Session session = null;
		Transaction tx = null;
		try {
			SessionFactory factory= factory=new Configuration()
                    .configure("hibernate.cfg.xml")
		            .buildSessionFactory();
			session = factory.openSession();
			tx = session.beginTransaction();
			User user = new UserService().register();
			session.save(user);
			tx.commit();

			return 1;
		} catch (Exception e) {
			e.printStackTrace();
			return 0;
		} finally {
			if (session != null) {
				session.close();
			}
		}

	}

	public User login() {
		Session session = null;
		Transaction tx = null;
		User usResponse=new User();
		try {
			SessionFactory factory= factory=new Configuration()
                    .configure("hibernate.cfg.xml")
		            .buildSessionFactory();
			session = factory.openSession();
		
			tx = session.beginTransaction();
			UserRequest user = new UserService().login();
			Query<User> query = session.createQuery(
					"From User where uname='" + user.getUname() + "' and password='" + user.getPassword() + "'");
			usResponse = query.uniqueResult();
				
			
			return usResponse;
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			return null;
		}
		}

	public List<User> listOfUsers() {
		// TODO Auto-generated method stub
		SessionFactory factory= factory=new Configuration()
                .configure("hibernate.cfg.xml")
	            .buildSessionFactory();
	Session	session = factory.openSession();
	Transaction tx =session.beginTransaction();
		Query query=session.createQuery("From User  ");
		
		return query.list();
	}
	
	@Override
	public User findById(int id) {
		// TODO Auto-generated method stub
		SessionFactory factory= factory=new Configuration()
                .configure("hibernate.cfg.xml")
	            .buildSessionFactory();
	Session	session = factory.openSession();
	Transaction tx =session.beginTransaction();
		Query query=session.createQuery("From User u where u.id=:id");
		query.setParameter("id", id);
		List<User> user=query.list();
		return user.get(0);
	}

	//healthcare module

	public List<Healthcare> listOfHealthcare() {
		// TODO Auto-generated method stub
		SessionFactory factory= factory=new Configuration()
                .configure("hibernate.cfg.xml")
	            .buildSessionFactory();
	Session	session = factory.openSession();
	Transaction tx =session.beginTransaction();
		Query query=session.createQuery("From Healthcare ");
		
		return query.list();
	}
	
	@Override
	public Healthcare productList() {
		// TODO Auto-generated method stub
		Session session = null;
		Transaction tx = null;
		try {
			SessionFactory factory= factory=new Configuration()
                    .configure("hibernate.cfg.xml")
		            .buildSessionFactory();
			session = factory.openSession();
			tx = session.beginTransaction();
			Healthcare health = new HealthCareService().productList();
			session.save(health);
			tx.commit();

			return health;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
	
	//Electronics module
	
	@Override
	public List<Electronics> listOfElectronics() {
		// TODO Auto-generated method stub
		SessionFactory factory= factory=new Configuration()
                .configure("hibernate.cfg.xml")
	            .buildSessionFactory();
	Session	session = factory.openSession();
	Transaction tx =session.beginTransaction();
		Query query=session.createQuery("From Electronics");
		
		return query.list();
	}
	
	public Electronics productList2() {
		// TODO Auto-generated method stub
		Session session = null;
		Transaction tx = null;
		try {
			SessionFactory factory= factory=new Configuration()
                    .configure("hibernate.cfg.xml")
		            .buildSessionFactory();
			session = factory.openSession();
			tx = session.beginTransaction();
			Electronics electronic = new ElectronicsCareSer().productList2();
			session.save(electronic);
			tx.commit();

			return electronic;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}
		
	
	//fashion module
	

	@Override
	public List<Fashion> listOfFashion() {
		// TODO Auto-generated method stub
		SessionFactory factory= factory=new Configuration()
                .configure("hibernate.cfg.xml")
	            .buildSessionFactory();
	Session	session = factory.openSession();
	Transaction tx =session.beginTransaction();
		Query query=session.createQuery("From Fashion");
		
		return query.list();
	}

	

	@Override
	public Fashion productList1() {
		// TODO Auto-generated method stub
		Session session = null;
		Transaction tx = null;
		try {
			SessionFactory factory= factory=new Configuration()
                    .configure("hibernate.cfg.xml")
		            .buildSessionFactory();
			session = factory.openSession();
			tx = session.beginTransaction();
			Fashion fashion = new FashionCareSer().productList1();
			session.save(fashion);
			tx.commit();

			return fashion;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			if (session != null) {
				session.close();
			}
		}
	}


}
