package com.app.categories;

import java.util.List;
import java.util.Scanner;

import com.app.dao.USerDao;
import com.app.factory.UserFactory;

import com.app.model.Healthcare;
import com.app.ship.ShipClient;

public class HealthcareCat {
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		USerDao dao=UserFactory.getUser();
		List<Healthcare>list1=dao.listOfHealthcare();
		list1.stream().forEach(s->System.out.println("Product Id= "+s.getProid()+"\t"+"Product name= "+s.getProName()+" "));
		System.out.println("Enter Id of Product");
		Scanner sc=new Scanner(System.in);
		int i=sc.nextInt();
		
		int id =i;
		if(i==id ) {
			ShipClient.main(args);
		}
	}

}
