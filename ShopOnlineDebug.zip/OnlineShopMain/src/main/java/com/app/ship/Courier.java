package com.app.ship;

public interface Courier {
	String deliver(int orderId);

}
