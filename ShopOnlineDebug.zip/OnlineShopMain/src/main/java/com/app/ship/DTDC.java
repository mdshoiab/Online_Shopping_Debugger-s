package com.app.ship;

public class DTDC implements Courier {

	public final String deliver(int orderId) {
		// TODO Auto-generated method stub
		return orderId+" (orderId) products are delivering by (DTDC)";
	}

	
}
