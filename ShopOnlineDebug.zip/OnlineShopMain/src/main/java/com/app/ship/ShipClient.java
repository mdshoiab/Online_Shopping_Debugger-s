package com.app.ship;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


public class ShipClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Product added in cart");
		System.out.println("Enter your full address to ship the product....");
		Scanner sn=new Scanner(System.in);
		String add=sn.next();
		
		ApplicationContext ctx=new ClassPathXmlApplicationContext("applicationcontext.xml");
		OnlineShop flipkart=(OnlineShop)ctx.getBean("Debugger");
		System.out.println(flipkart.shopping(new String[] {"Product is Booked"}));
		
	}

}

