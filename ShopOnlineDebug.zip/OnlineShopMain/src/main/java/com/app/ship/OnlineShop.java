package com.app.ship;

import java.util.Arrays;
import java.util.Random;



public class OnlineShop {
	private Courier courier;

	public void setCourier(Courier courier) {
		this.courier = courier;
	}


	public String shopping(String[] items) {
		// TODO Auto-generated method stub
		
		Random ran=new Random();
		int orderId=ran.nextInt(1000000);
		
		String msg=courier.deliver(orderId);
		return Arrays.toString(items)+msg;

	}

}
