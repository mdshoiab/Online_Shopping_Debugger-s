package com.app.test;

import java.util.List;
import java.util.Scanner;

import com.app.categories.ElectronicsCat;
import com.app.categories.FashionCat;
import com.app.categories.HealthcareCat;
import com.app.dao.USerDao;
import com.app.factory.UserFactory;
import com.app.model.Electronics;
import com.app.model.Fashion;
import com.app.model.Healthcare;



public class Portal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		USerDao dao=UserFactory.getUser();
		Scanner sc=new Scanner(System.in);
		System.out.println("--------------Welcome To Debugger's Online Shopping-----------------");
		System.out.println();
		System.out.println("Enter your choise");
	
		System.out.println("press 1 for HealthCare Product");
		System.out.println("press 2 for Fashion Care");
		System.out.println("press 3 for Electronics Care");
		int choice=sc.nextInt();
		String ch="";
		switch(choice) {
		
		case 1:	 
				HealthcareCat.main(args);
		break;
		case 2:	 
			FashionCat.main(args);
			
		break;
		
		case 3:	 
			ElectronicsCat.main(args);
			
		break;
		
		default:System.out.println("do you want to continue press y/Y");
			sc.next();
		while (ch.equalsIgnoreCase("y"));
	}
	}

}
