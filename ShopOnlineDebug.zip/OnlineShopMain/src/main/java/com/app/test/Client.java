package com.app.test;

import java.util.List;
import java.util.Scanner;

import com.app.dao.USerDao;
import com.app.factory.UserFactory;
import com.app.model.Electronics;
import com.app.model.Fashion;
import com.app.model.Healthcare;
import com.app.model.User;
import com.app.util.HibernateUtil;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sn=new Scanner(System.in);
USerDao dao=UserFactory.getUser();
String ch="";
do {
	System.out.println("Welcome To Online Shopping Project");
	System.out.println("Press 1: for Register");
	System.out.println("Press 2: for Login");
	System.out.println("Press 3: for Display Users");
	System.out.println("Press 4: for Display User on id");
	
	System.out.println("-------------------------------");
	System.out.println("Enter Your Choice:");
	int choice=sn.nextInt();
	switch (choice) {
	case 1:
		int i=dao.register();
		if(i==1) {
			System.out.println("Successfully Register");
		}else {
			System.out.println("Something went wrong...!");
		}
		break;
	case 2:
		User user=dao.login();
		if(user!=null &&user.getRole().equalsIgnoreCase("admin")) {
			System.out.println("welcome to admin portal.");
			System.out.println("Vendor Product Addition");
			System.out.println("Press 1 Vendor Product Addition- HealthCare ");
			System.out.println("Press 2 Vendor Product Addition- Fashion");
			System.out.println("Press 3 Vendor Product Addition- Electronics");
			int i1=sn.nextInt();
			if(i1==1) {
			Healthcare p=dao.productList();
			System.out.println("record inserted");
			}
			else if(i1==2) {
				Fashion f=dao.productList1();
				System.out.println("record inserted");
				}
			else if(i1==3) {
				Electronics  e=dao.productList2();
				System.out.println("record inserted");
				}
		}else if(user!=null &&user.getRole().equalsIgnoreCase("user")){
			System.out.println("Welcome to User Portal.. press 1");
			int i1=sn.nextInt();
			if(i1==1) {
				Portal.main(args);
			}
		}else {
			System.out.println("Invallid username and password");
		}
		break;
	case 3:
		List<User>list=dao.listOfUsers();
		list.stream().forEach(s->System.out.println(s.getId()+"\t"+s.getFisrtName()+" "+s.getLastName()+"\t"+s.getAddress()+"\t"+s.getMobile()));
		break;
	case 4:
		System.out.println("Enter your id for find user:");
		int id=sn.nextInt();
		User u1=dao.findById(id);
		System.out.println(u1);
		break;
		
	default:
		System.out.println("Invalid Request...!");
		break;
	}
	System.out.println("Do you want to continue...(y)");
	ch=sn.next();
}while(ch.equalsIgnoreCase("y"));
System.out.println("Thank you");
	}

}
